<?php
	session_start();


	require 'core/library/main.php';
	require 'core/library/admin.php';
	require 'core/library/users.php';
	require 'core/library/products.php';

	
	require 'core/models/db.php';
	require 'core/models/cart.php';
	require 'core/models/users.php';
	require 'core/models/images.php';
	require 'core/models/products.php';




	if(!isset($_COOKIE['user_sess_id']))
	{
		$user_sess_id = md5(generateString());
		setcookie('user_sess_id', $user_sess_id, time()+360000, '/');	
		$_SESSION['user_sess_id'] = $_COOKIE['user_sess_id'];
		$res = addUserCountProduct($user_sess_id);
	}



	$controllerName = getUrlSegment(0);
	$actionName = getUrlSegment(1);

	if(!empty($controllerName)){
		$controllerName = getUrlSegment(0);
	}else {
		$controllerName = "main";
	}

	if(!empty($actionName)){
		$actionName = "action_" . getUrlSegment(1);
	}else {
		$actionName = "action_index";
	}

	if($controllerName != 'ajax' && $actionName != 'getProducts')
	{
		unset($_SESSION['n']);
	}

	$controllerPath = "core/controllers/" . $controllerName . ".php";
	if(file_exists($controllerPath)){
		require $controllerPath;
		if(function_exists($actionName)){
			$actionName();
		}else {
			show404page();
		}
	}else {
		show404page();
	}
?>