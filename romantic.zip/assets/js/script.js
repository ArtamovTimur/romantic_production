// Подстветка ссылки активной стараницы

$(document).ready(function(){
	$('.menu span a').each(function() {
		if(this.href == location.href) $(this).parent().addClass('active');
	});

// Кнопка наверх

	$('.go-to-top').click(function () {
				$('body,html').animate({
					scrollTop: 0
				}, 1000);
				return false;
	});

	// показать больше картинок

	$('#gallery-two').css('display', 'none');
	$('#gallery-three').css('display', 'none');
	$('#gallery-four').css('display', 'none');
	$('#gallery-five').css('display', 'none');

	$('.all-img').on('click', function(){
		$.ajax({
			url: '/ajax/getImages',
			type: 'POST',
			dataType: 'html',
			data: {param1: 'value1'},
		})
		.done(function(data) {
			switch (data) {
				case '0':
					$('#gallery-two').css('display', 'flex');
					break;
				case '1':
					$('#gallery-three').css('display', 'flex');
					break;
				case '2':
					$('#gallery-four').css('display', 'flex');
					break;
				case '3':
					$('#gallery-five').css('display', 'flex');
					break;
				
			}

		})
		.fail(function() {
			console.log("error");
		})
		.always(function() {
			console.log("complete");
		});
		
	});

	////////////////////////////////

	$('#get-products').on('click', function(){
		var productsCount = document.querySelectorAll('.product');
		var count = productsCount.length-1;
		var lastProductId = productsCount[count].id;
		console.log(lastProductId);
		$.ajax({
			url: '/ajax/getProducts',
			type: 'POST',
			dataType: 'html',
			data: {'last_id': lastProductId}
		})
		.done(function(data) {		
			if(data.length != 0){
				var array = JSON.parse(data);
				for(var i = 0; i <= array.length-1; i++){
					var product = 
					`<div class="product" id="${array[i].id}">
						<img src=/${array[i].photo_name} alt="" width="100%">
						<div class="posBlock">
							<h3>Быстрый просмотр</h3>
						</div>
						<div class="product-title">
							${array[i].title}
							<span class="old-price"><br>
								<strike>${array[i].price-200}</strike>
							</span>&nbsp;
							<span class="price">${array[i].price}&nbsp;₸</span>
						</div>
					</div>`;
					$('.products-wrap').append(product);
				}
			}
			$('.product').bind('click', function(){
				var id = $(this).attr('id');
				document.location.href='/products/product?id=' + id;
			});
		})
		.fail(function() {
			console.log("error");
		})
		.always(function() {
			console.log("complete");
		});
		
	});
	///////////////////////////////////////
	var h = $(window).height() + 'px';
	$('.cart-block').css({
		'height': h,
		'z-index': '9999999999',
		'display': 'none',
		'position': 'fixed'
	});

	$('.cart-btn').click(function(){
		var price = parseInt($('.pr').html());
		var all_count = $('.product-in-cart').length-1;
		var product_count = $('pcount');
		var product_price = $('pprice');
		
		for(var i = 0; i <= all_count; i++){
			price += parseInt($('.pcount').eq(i).html()) * parseInt($('.pprice').eq(i).html())
		}
		$('.pr').html(price);

		
		$('.cart-block').show(500);
	});

	$(document).mouseup(function (e) {
	    var container = $(".cart-block");
	    if (e.target!=container[0] && !container.has(e.target).length){
	        container.fadeOut();
	    }
	});

	// $('.posBlock').click(function(){
	// 	var imgPath = $(this).parent().find('img').attr('src');
	// 	$('.showImgBlock').css({
	// 		'height': $(window).height(),
	// 		'display': 'block'
	// 	});
	// 	var img = "<img src='" + imgPath+ "' alt=''/>";
	// 	$('.showImgBlock').append(img);
	// 	$(document.body).css('position', 'fixed');
	// });

	$('.product').click(function(){
		var id = $(this).attr('id');
		document.location.href='/products/product?id=' + id;
	});

	$('.img-preview').bind('click', function(){
		var imgPath = $(this).attr('src');
		$('.show-img img').attr('src', imgPath);
	});

	$('.add-in-cart').click(function(){
		var product_id = $(this).attr('data-id');
		$.ajax({
			url: '/cart/addToCart',
			type: 'POST',
			dataType: 'html',
			data: {'product_id': product_id, 'count': $('.count-number').val()}
		})
		.done(function(data) {
				if(data.length > 0){
					var products_data = JSON.parse(data);
					for(var j = 0; j <= products_data.length-1; j++)
					{
						var product = `
							<div class="product-in-cart-block">
								<div class="product-in-cart">
									<div class="product-in-cart-title">${products_data[j][0].title}</div>
									<img src="/${products_data[j][0].photo_name}" alt="" width="40%" class="product-in-car-img">
								
									<div class="product-in-count"><strong>Количество:dd</strong>&nbsp;454</div>
									<div class="price">Цена:&nbsp;${products_data[j][0].price}</div>
									<div class="delete-product">Убрать из корзины</div>
								</div>
							</div>
						`;
						$('.cart-block').append(product);
						location.reload();
					}
			}
			

			var cartProductCount = $('.product-in-cart-block').length;
			$('.cart-count').html(cartProductCount);
		})
		.fail(function() {
			console.log("error");
		})
		.always(function() {
			console.log("complete");
		});
		
	});

	$('.delete-product').click(function(){
		var product_id = $(this).attr('data-id');
		$.ajax({
			url: '/cart/deleteToCart',
			type: 'POST',
			dataType: 'html',
			data: {'product_id': product_id},
		})
		.done(function(data) {
			$('cart-count').html(data);
			location.reload();
		})
		.fail(function() {
			console.log("error");
		})
		.always(function() {
			console.log("complete");
		});
		
	});

});


