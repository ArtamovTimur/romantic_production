$(function(){
	setInterval(function(){console.log('hi')}, 1000);	
});
