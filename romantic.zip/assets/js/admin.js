$(function(){
	$('.menu-btn').on('click',function(){
		if($('.right-menu').css('display') != 'block'){
			$('.right-menu').fadeIn(500);
			$('.menu-btn').fadeOut(500);
		}else {
			$('.right-menu').fadeOut(500);
		}
		
	});	

	$(document).mouseup(function(e) {
	    var container = $(".right-menu");
	    if(e.target!=container[0] && !container.has(e.target).length){	
	    container.fadeOut();
	    $('.menu-btn').fadeIn(500);
	}});

	$('.descp').focus(function() {
  		$(this).setCursorPosition(1);
	});

	$('.descp').click(function() {
  		$(this).setCursorPosition(1);
	});
});