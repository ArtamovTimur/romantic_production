<?php
	function action_addNewProduct()
	{

		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{	
			$formData = [
				'product_title' => htmlspecialchars(trim($_POST['product_title'])),
				'product_price' => htmlspecialchars($_POST['product_price']),
				'product_description' => htmlspecialchars(trim($_POST['product_description']))
			];
			$formData['photo_name'] = addProductPhoto();
			if(!empty($formData['product_title']) && !empty($formData['product_price'])
			&& !empty($formData['product_description']))
			{
				
				if(addNewProduct($formData))
				{	
					$names = addAllPhotos();
					savePhotosName(getLastProductId(), $names);
					header('Location: /products/allProducts');
				}else {
					renderAdmin('add_new_product', ['error' => 'Товар не добавлен!']);
				}
			}else {
				renderAdmin('add_new_product', ['error' => 'Заполните все поля!']);
			}
			
		}else {
			renderAdmin('add_new_product', []);
		}
	}

	function action_updateProduct()
	{

	}

	function action_deleteProduct()
	{
		if(!empty($_GET['id']))
		{
			$imgName = getImageNameById($_GET['id']);
			deleteProduct($_GET['id']);
			$imagesName = getImagesForProductById($_GET['id']);
			$imagesLength = count(getImagesForProductById($_GET['id']));
			for($i = 0; $i <= (int)$imagesLength-1; $i++)
			{	
				unlink($imagesName[$i]['photo_name']);
			}
			unlink($imgName);
			header('Location: /products/allProducts');

		}
		else {
			header('Location: /products/allProducts');
		}
	}

	function action_allProducts()
	{
		if($_SESSION['auth']){
			$products = getAllProducts();
			renderAdmin('all_products', ['products' => $products]);
		}else {
			header('Location: /admin');
		}
		
	}

	function action_product()
	{
		if(!empty($_GET['id'])){
			$id = htmlspecialchars(strtolower($_GET['id']));
			$product = getProductById($id);
			$images = getImagesForProductById($id);

			$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
			$productCount = getProductCountById($_COOKIE['user_sess_id']);
			if(!empty($idArray))
			{
				$productsData = [];
					for($i = 0; $i <= count($idArray)-1; $i++)
					{
						$productsData[] = getProductById($idArray[$i]['product_id']);
						
					}
			}else {
				$productsData = [];
				
			}

			renderView('product', ['product' => $product, 'images' => $images, 'products_count' => getProductsCountBuUserId($_COOKIE['user_sess_id']),
		'cart_products' => $productsData, 'product_count' => $productCount]);
		}else {
			show404page();
		}
		
	}

	function action_test()
	{	
		var_dump(addAllPhotos());
	}
?>