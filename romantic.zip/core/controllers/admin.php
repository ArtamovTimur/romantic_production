<?php
	function action_index()
	{
		if($_SESSION['auth'])
		{
			header('Location: /admin/main');
		}else {
			renderAdmin('index');
		}
		
	}

	function action_auth()
	{

		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{	
			$formData = [
				'login' => htmlspecialchars(trim($_POST['admin_login'])),
				'password' => htmlspecialchars(trim($_POST['admin_password']))
			];
			if(!empty($formData['login']) && !empty($formData['password']))
			{
				if(checkAdmin($formData['login'], $formData['password'])){
					$_SESSION['auth'] = true;
					header('Location: /admin/main');
				}else {
					renderAdmin('index', ['errors' => 'Неверный логин или парооль!']);
				}
			}else {
				renderAdmin('index', ['errors' => 'Заполните все поля!']);
			}
			
		}else {
			header('Location: /admin', []);
		}
	}

	function action_main()
	{
		if($_SESSION['auth']){
			renderAdmin('main', []);	
		}else {
			header('Location: /admin');
		}
	}

	function action_logout()
	{
		unset($_SESSION['auth']);
		session_destroy();
		header('Location: /admin');
	}

	function action_test()
	{
		var_dump(getUserRoleByLoginAndPassword('tima99','qwerty'));
		var_dump(checkAdmin('tima99', 'qwerty'));
	}


?>