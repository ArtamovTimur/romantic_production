<?php
	
	function action_index()
	{

	}

	function action_allUsers()
	{
		if($_SESSION['auth']){
			$allUsers = getAllUsers();
			renderAdmin('all_users', ['usres' => $allUsers]);	
		}else {
			header('Location: /admin');
		}

	}

	function action_deleteUser()
	{

	}

?>