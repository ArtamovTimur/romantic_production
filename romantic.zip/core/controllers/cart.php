<?php
	function action_addToCart()
	{
		$user_sess_id = $_COOKIE['user_sess_id'];
		$product_id = (int)$_POST['product_id'];
		$count = (int)$_POST['count'];
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			
			if(getProductToCart($user_sess_id, $product_id)->num_rows >= 1)
			{
				$newCount = (int)getProductCount($user_sess_id, $product_id);
				$res = updateProductCount($user_sess_id, $product_id, $newCount+$count);
				
			}else {
				$oldCount = getProductsCountBuUserId($user_sess_id);
				$inc = incProductCount((int)$oldCount+1, $user_sess_id);
				$res = addToCart($user_sess_id, $product_id, $count);
				
				$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
		
				if(!empty($idArray))
				{
					$productsData = [];
						for($i = 0; $i <= count($idArray)-1; $i++)
						{
							$productsData[] = getProductById($idArray[$i]['product_id']);
						}
				}else {
					$productsData = [];
				}
				echo json_encode($productsData);
			}
		}
	}
	function action_deleteToCart()
	{
		$user_id = $_COOKIE['user_sess_id'];
		$product_id = $_POST['product_id'];
		if(deleteToCart($user_id, $product_id))
		{
			setCartCountByUserId(getProductsCountBuUserId($user_id)-1, $user_id);
			echo getProductsCountBuUserId($user_id);
			
		}else {
			echo 'no';
		}
	}

	function action_test()
	{
	
	}

?>