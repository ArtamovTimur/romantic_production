<?php
	function action_getImages()
	{
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{	
			$count = $_SESSION['images_count'];
			echo $count;
			$_SESSION['images_count'] += 1;
		}
	}

	function action_getProducts()
	{
		$data = getProductsByCount($_POST['last_id'], 3);
		echo json_encode($data);
	}

	function action_getRequest()
	{

	}
?>