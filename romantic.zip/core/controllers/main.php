<?php
	function action_index()
	{
		$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
		$productCount = getProductCountById($_COOKIE['user_sess_id']);
		if(!empty($idArray))
		{
			$productsData = [];
				for($i = 0; $i <= count($idArray)-1; $i++)
				{
					$productsData[] = getProductById($idArray[$i]['product_id']);
					
				}
		}else {
			$productsData = [];
		}
		renderView("index", ['products_count' => getProductsCountBuUserId($_COOKIE['user_sess_id']), 'cart_products' => $productsData, 'product_count' => $productCount]);
		$_SESSION['images_count'] = 0;
	}

	function action_about()
	{
		$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
		$productCount = getProductCountById($_COOKIE['user_sess_id']);
		if(!empty($idArray))
		{
			$productsData = [];
				for($i = 0; $i <= count($idArray)-1; $i++)
				{
					$productsData[] = getProductById($idArray[$i]['product_id']);
					
				}
		}else {
			$productCount = [];
		}

		renderView("about", ['products_count' => getProductsCountBuUserId($_COOKIE['user_sess_id']), 'cart_products' => $productsData, 'product_count' => $productCount]);
	}

	function action_magazine()
	{		
		$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
		$productCount = getProductCountById($_COOKIE['user_sess_id']);
		if(!empty($idArray))
		{
			$productsData = [];
				for($i = 0; $i <= count($idArray)-1; $i++)
				{
					$productsData[] = getProductById($idArray[$i]['product_id']);
					
				}
		}else {
			$productsData = [];
		}

		$data = getFixedProductsByCount(9);
		renderView("magazine", ['products' => $data, 'products_count' => getProductsCountBuUserId($_COOKIE['user_sess_id']), 'cart_products' => $productsData, 'product_count' => $productCount]);

	}

	function action_payment()
	{
		$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
		$productCount = getProductCountById($_COOKIE['user_sess_id']);
		if(!empty($idArray))
		{
			$productsData = [];
				for($i = 0; $i <= count($idArray)-1; $i++)
				{
					$productsData[] = getProductById($idArray[$i]['product_id']);
					
				}
		}else {
			$productsData = [];
			
		}

		renderView("payment", ['products_count' => getProductsCountBuUserId($_COOKIE['user_sess_id']), 'cart_products' => $productsData, 'product_count' => $productCount]);
	}

	function action_care()
	{	
		$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
		$productCount = getProductCountById($_COOKIE['user_sess_id']);
		if(!empty($idArray))
		{
			$productsData = [];
				for($i = 0; $i <= count($idArray)-1; $i++)
				{
					$productsData[] = getProductById($idArray[$i]['product_id']);
					
				}
		}else {
			$productsData = [];
			
		}

		renderView("care", ['products_count' => getProductsCountBuUserId($_COOKIE['user_sess_id']), 'cart_products' => $productsData, 'product_count' => $productCount]);
	}

	function action_franchise()
	{
		$idArray = getAllIdCartProductBuUser($_COOKIE['user_sess_id']);
		$productCount = getProductCountById($_COOKIE['user_sess_id']);
		if(!empty($idArray))
		{
			$productsData = [];
				for($i = 0; $i <= count($idArray)-1; $i++)
				{
					$productsData[] = getProductById($idArray[$i]['product_id']);
					
				}
		}else {
			$productsData = [];
			
		}

		renderView("franchise", ['products_count' => getProductsCountBuUserId($_COOKIE['user_sess_id']), 'cart_products' => $productsData, 'product_count' => $productCount]);
	}

	function action_test()
	{
		$idArray = getAllIdCartProductBuUser('aee8c88b6f1a105fde9b2650a1ff3ef3');
		$data = [];
		for($i = 0; $i <= count($idArray)-1; $i++)
		{
			$data[] = getProductById($idArray[$i]['product_id']);
		}
		
	}

?>