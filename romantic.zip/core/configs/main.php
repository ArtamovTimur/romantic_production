<?php
	// return [
	// 	'db_host' => 'localhost',
	// 	'db_user' => 'root',
	// 	'db_password' => '',
	// 	'db_name' => 'romantic'
	// ];	

	return [
		'db_host' => 'localhost',
		'db_user' => 'cv19562_romantic',
		'db_password' => 'qwerty',
		'db_name' => 'cv19562_romantic'
	];	
?>