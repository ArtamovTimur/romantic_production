<?php

	function addNewUser($data)
	{

	}

	function updateUser($id)
	{

	}

	function deleteUser($id)
	{

	}

	function getAllUsers()
	{
		return db_get_data_from_table('rom_users');
	}

	function getUserRoleByLoginAndPassword($userLogin, $userPassword)
	{
		$sql = "SELECT role FROM rom_users WHERE login='{$userLogin}' AND password='{$userPassword}'";
		$dbh = db_query($sql);
		return $dbh;
	}


	function checkUserRoleByLogin($userLogin)
	{

	}

?>