<?php
	function getAllProducts()
	{
		return db_get_data_from_table('rom_products');
	}

	function addNewProduct($data = [])
	{
		$sql = "INSERT INTO rom_products (`title`, `price`, `description`, `photo_name`)
		VALUES ('{$data['product_title']}', '{$data['product_price']}', '{$data['product_description']}', '{$data['photo_name']}')";
		$res = db_query($sql);
		if(!$res){
			return false;
		}else { 
			return true;
		}
	}
	function deleteProduct($id)
	{
		$sql = "DELETE FROM rom_products WHERE id=$id";
		db_query($sql);
	}

	function getImageNameById($id)
	{
		$sql = "SELECT photo_name FROM rom_products WHERE id=$id";
		$dbh = db_query($sql);
		$res = mysqli_fetch_assoc($dbh)['photo_name'];
		return $res;
	}

	function getProductsByCount($old, $count)
	{
		$sql = "SELECT * FROM rom_products LIMIT $old, $count";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function getFixedProductsByCount($count)
	{
		$sql = "SELECT * FROM rom_products LIMIT $count";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function getProductById($id)
	{
		$sql = "SELECT * FROM rom_products WHERE id=$id";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function getLastProductId()
	{
		$sql = "SELECT MAX(`id`) FROM `rom_products`";
		$dbh = db_query($sql);
		return mysqli_fetch_assoc($dbh)["MAX(`id`)"];
	}

	function getAllIdCartProductBuUser($user_sess_id)
	{
		$sql = "SELECT product_id FROM `rom_cart` WHERE user_sess_id='{$user_sess_id}'";
		$dbh = db_query($sql);
		$res = db_fetch_data($dbh);
		return $res;
	}

	function getProductCountById($user_id)
	{
		$sql = "SELECT product_count FROM `rom_cart` WHERE user_sess_id='{$user_id}'";
		$dbh = db_query($sql);
		return db_fetch_data($dbh);
		
	}



?>