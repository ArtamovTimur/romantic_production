<?php
	function getImagesByCount($old, $count)
	{
		$sql = "SELECT * FROM rom_images LIMIT $old, $count";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function getImagesForProductById($productId)
	{
		$sql = "SELECT * FROM rom_products_images WHERE product_id=$productId";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}


	function savePhotosName($id, $names)
	{
		$product_id = (int)$id;
		$all_photos = $_FILES['all_photo']['name'];
		for($i = 0; $i <= count($all_photos)-1; $i++){
			$imgName = $names[$i];
			$sql = "INSERT INTO rom_products_images (`product_id`, `photo_name`) VALUES ($product_id, '{$imgName}')";
			$db = db_query($sql);
		}
	}
?>