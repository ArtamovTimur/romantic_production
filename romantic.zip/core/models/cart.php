<?php
	function addToCart($user_sess_id, $product_id, $count)
	{
		$sql = "INSERT INTO `rom_cart` (user_sess_id, product_id, product_count)
		VALUES('{$user_sess_id}', '{$product_id}', '{$count}')";
		$dbh = db_query($sql);
		return $dbh;
	}

	function getProductToCart($user_id, $product_id)
	{
		$sql = "SELECT * FROM `rom_cart` WHERE user_sess_id='{$user_id}' AND product_id='{$product_id}'";
		$dbh = db_query($sql);
		return $dbh;	
	}
	function getProductCount($user_id, $product_id)
	{
		$sql = "SELECT product_count FROM `rom_cart` WHERE user_sess_id='{$user_id}' AND product_id='{$product_id}'";
		$dbh = db_query($sql);
		$data = mysqli_fetch_assoc($dbh)['product_count'];
		return $data;
	}
	function updateProductCount($user_id, $product_id, $data)
	{
		$sql = "UPDATE `rom_cart` SET product_count='{$data}' WHERE user_sess_id='{$user_id}' AND product_id='{$product_id}'";
		$dbh = db_query($sql);
		return $dbh;
	}

	function getProductsCountBuUserId($user_id)
	{
		$sql = "SELECT product_count FROM `rom_products_count` WHERE user_id='{$user_id}'";
		$dbh = db_query($sql);
		$data = mysqli_fetch_assoc($dbh)['product_count'];
		return $data;
	}

	function incProductCount($count, $user_id)
	{
		$sql = "UPDATE `rom_products_count` SET product_count='{$count}' WHERE user_id='{$user_id}'";
		$dbh = db_query($sql);
		return $dbh;
	}

	function addUserCountProduct($user_id)
	{
		$sql = "INSERT INTO `rom_products_count` (user_id, product_count) VALUES('{$user_id}', '0')";
		$dbh = db_query($sql);
		return $dbh;
	}

	function deleteToCart($user_id, $product_id)
	{
		$sql = "DELETE FROM `rom_cart` WHERE user_sess_id='{$user_id}' AND product_id='{$product_id}'";
		$dbh = db_query($sql);
		return $dbh;
	}

	function setCartCountByUserId($count, $user_id)
	{
		$sql = "UPDATE `rom_products_count` SET product_count='{$count}' WHERE user_id='{$user_id}'";
		$dbh = db_query($sql);
		return $dbh;
	}

?>