<?php
	function addProductPhoto()
	{
		if(isset($_FILES['product_photo']))
		{
					$imgName = 'assets/img/products/' . generateString() . $_FILES['product_photo']['name'];
					if($_FILES['product_photo']['error'] == 0)
					{
						$res = move_uploaded_file($_FILES['product_photo']['tmp_name'],
							$imgName);
						return $imgName;
					}
					else 
					{
						echo "Ошибка загрузки изображения";
						die();
					}
		}
		else 
		{
			return false;
		}
	}

	function addAllPhotos()
	{
		$all_photos = $_FILES['all_photo'];
		for($i = 0; $i <= count($all_photos)-1; $i++){
			if(!empty($_FILES['all_photo']['name'][$i]))
			{
				$imgName = 'assets/img/products_show/' . generateString() . $_FILES['all_photo']['name'][$i];
				$name[$i] = $imgName;
				$res = move_uploaded_file($_FILES['all_photo']['tmp_name'][$i],
							$imgName);
			}
		}
		return $name;
	}

	
?>