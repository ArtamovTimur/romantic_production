<?php
	function renderAdmin($view, $data = [])
	{
		require 'core/views/admin/' . $view . '.php';
	}

	function checkAdmin($login, $password)
	{
		$dbh = getUserRoleByLoginAndPassword($login, $password);
		$data = db_fetch_data($dbh);
		if(!is_null($data) && !empty($data)){
			return true;
		}else {
			return false;
		}
	}
?>