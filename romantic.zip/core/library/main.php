<?php
	function getUrlSegment($n)
	{
		$url = explode('/', strtolower($_GET['url']));
		return $url[$n];
	}

	function show404page()
	{
		require '/core/views/layouts/404.php';
	}

	function renderView($view, $data = [])
	{
		require "core/views/layouts/" . $view . ".php";
	}

	function generateString($length = 8){
 		 $chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
  		$numChars = strlen($chars);
  		$string = '';
  		for ($i = 0; $i < $length; $i++) {
  		  $string .= substr($chars, rand(1, $numChars) - 1, 1);
  		}
 		 return $string;
	}

?>