	<?php require 'core/views/templates/header.tpl'; ?>
	<?php
		$products = $data['products'];
	?>
	<div class="showImgBlock">
		
	</div>
	<div class="content">
		<h1>Онлайн витрина</h1>
		<div class="products-wrap">
			<?php
				for($i = 0; $i <= count($products)-1; $i++):
			?>
			<div class="product" id="<?= $products[$i]['id']; ?>">
				
				<img src="/<?= $products[$i]['photo_name']; ?>" alt="" width="100%">
				<div class="posBlock">
					<h3>Быстрый просмотр</h3>
				</div>
				<div class="product-title">
					<?= $products[$i]['title']; ?><br>
					<span class="old-price"><strike>600</strike></span><span class="price">&nbsp;<?= $products[$i]['price'];?>&nbsp;₸</span>
				</div>
			</div><!-- product end -->

			<?php
				endfor;
			?>
			
		</div><!-- products wrap end -->
	</div>
	<div class="all-btn" id="get-products">ПОКАЗАТЬ БОЛЬШЕ</div>

	<?php require 'core/views/templates/footer.tpl'; ?>