<?php
	if(!empty($data['product']))
	{
		$product = $data['product'][0];
	}
	if(!empty($data['images']))
	{
		$images = $data['images'];
	}
	if(!empty($data['products_count'])){
		$products_count = $data['products_count'];
	}else {
		$products_count = 0;
	}
?>
<?php require 'core/views/templates/header.tpl'; ?>

<div class="show-wrap">
	<div class="show-left">
		<div class="show-img">	
			<img src="/<?= $product['photo_name']; ?>" alt="" width="100%">
		</div>
		<div class="clear"></div>
		<div class="images-preview">
			<?php for($i = 0; $i <= count($images)-1; $i++):?>
				<img src="/<?= $images[$i]['photo_name']; ?>" alt="" width="10%" class="img-preview">
			<?php endfor;?>
		</div>
	</div>
	<div class="show-right">
		<h2 class="show-title"><?= $product['title']; ?></h2>
		<div class="show-price"><strike><?= $product['price']-1; ?></strike>&nbsp;<?= $product['price']; ?>&nbsp;₸</div>
		<span class="count-title">Количество:</span>
		<div class="clear"></div>
		<input type="number" class="count-number" min="1" value="1">
		<div class="clear"></div>
		<button class="add-in-cart" data-id="<?= $product['id']; ?>">Добавить в корзину</button>
	</div>
</div>


<?php require 'core/views/templates/footer.tpl'; ?>







