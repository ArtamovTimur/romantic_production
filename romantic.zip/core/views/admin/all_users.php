<?php
	if(!empty($data['users'])){
		$users = $data['users'];
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Все пользователи</title>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
	<script src="/assets/js/admin.js"></script>
</head>
<body>
	<h1>Список пользователей</h1>
	<h3>Имя</h3>
	<h3>olgin</h3>
	<h3>Номер телефона</h3>
	<h3>Адрес проживания</h3>
	
</body>
</html>