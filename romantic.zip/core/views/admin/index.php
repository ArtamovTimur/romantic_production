<?php
	if(!empty($data['errors'])) {$error = $data['errors']; echo "<h1>". $error ."</h1>"; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="/assets/css/admin.css">
</head>
<body>
	<h1>Панель администратора</h1>

	<div class="auth-form">
		<form action="/admin/auth" method="post">
			<h3>Введите логин</h3>
			<input type="text" name="admin_login">
			<h3>Введите пароль</h3>
			<input type="text" name="admin_password">
			<br><br>
			<input type="submit" value="Войти">
		</form>
	</div>
	
</body>
</html>