<?php
	if(!empty($data['error'])){
		$errors = $data['error'];
		echo "<h1>". $errros ."</h1>";
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="/assets/css/admin.css">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
	<script src="/assets/js/admin.js"></script>
</head>
<body>
	<?php require 'core/views/templates/admin_header.tpl'; ?>
	<h1>Добавление нового продукта</h1>
	<div class="add-new-product-form">
		<form action="/products/addNewProduct" method="post" enctype="multipart/form-data">
			<h3>title</h3>
			<input type="text" name="product_title">
			<h3>price</h3>
			<input type="number" name="product_price">
			<h3>description</h3>
			<textarea cols="50" rows="10" name="product_description" class="descp"></textarea>
			<h3>Главная фотография</h3>
			<input type="file" name="product_photo">
			<h3>Дополнительные фотографии</h3>
			<input type="file" name="all_photo[]">
			<input type="file" name="all_photo[]">
			<input type="file" name="all_photo[]">
			<input type="file" name="all_photo[]">
			<br><br>
			<input type="submit" value="Добавить">
		</form>
	</div>
</body>
</html>