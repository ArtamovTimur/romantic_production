<?php
	if(!empty($data['products'])){
		$products = $data['products'];
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="/assets/css/admin.css">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
	<script src="/assets/js/admin.js"></script>
</head>
<body>
	<?php require 'core/views/templates/admin_header.tpl'; ?>
	<h1 class="products-title">Список товаров</h1>
	<div class="products-block">

		<?php for($i = 0; $i <= count($products)-1; $i++): ?>
			<div class="product">
				<div class="product-title"><?= $products[$i]['title']; ?></div>
				<div class="product-price"><?= $products[$i]['price']; ?> тг</div>
				<div class="product-photo"><img src="/<?= $products[$i]['photo_name']; ?>" width='100%' /></div>
				<div class="product-date"><?= $products[$i]['pub_date']; ?></div>
				<div class="product-show"><a href="">Просмотреть</a></div>
				<div class="product-update"><a href="">Редактировать</a></div>
				<div class="product-remove"><a href="/products/deleteProduct?id=<?= $products[$i]['id']; ?>">Удалить</a></div>
			</div>
		<?php endfor; ?>
		

	</div>
	
	
</body>
</html>