<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="/assets/css/admin.css">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
	<script src="/assets/js/admin.js"></script>
</head>
<body>
	<?php require 'core/views/templates/admin_header.tpl'; ?>
	<h1>Добро пожаловать в панель Администратора!</h1>
	<div class="menu">
		<span><a href="/products/allProducts">Просмотр все товары</a></span><br>
		<span><a href="/products/addNewProduct">Добавить товар</a></span><br>
		<span><a href="/users/allUsers">Просмотр всех пользователей</a></span><br>
		<span><a href="">Просмотр текущих заказов</a></span><br>
		<span><a href="">Просмотр Google Analytics</a></span><br>
		<span><a href=""><a href="/admin/logout">Выйти</a></a></span>
	</div>
	

</body>
</html>